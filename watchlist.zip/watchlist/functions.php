<?php
/**
 * Watchlist child theme.
 */

const WL_WHATSAPP  = '254718995761';
const WL_INSTAGRAM = 'watchlistke';
const WL_FONTS     = 'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@500;600;700&family=Inter:wght@400;500;600;700&display=swap';

add_action( 'wp_enqueue_scripts', function () {
	$dir = get_stylesheet_directory();
	$uri = get_stylesheet_directory_uri();
	wp_enqueue_style( 'wl-fonts', WL_FONTS, [], null );
	wp_enqueue_style( 'wl', get_stylesheet_uri(), [], filemtime( $dir . '/style.css' ) );
	wp_enqueue_script( 'wl', $uri . '/assets/wl.js', [], filemtime( $dir . '/assets/wl.js' ), true );
	wp_localize_script( 'wl', 'WL', [
		'store' => esc_url_raw( rest_url( 'wc/store/v1/' ) ),
		'shop'  => esc_url_raw( wc_get_page_permalink( 'shop' ) ),
		'home'  => esc_url_raw( home_url( '/' ) ),
		'wa'    => WL_WHATSAPP,
	] );
} );

add_action( 'enqueue_block_editor_assets', function () {
	wp_enqueue_style( 'wl-fonts', WL_FONTS, [], null );
} );
add_action( 'after_setup_theme', function () {
	add_editor_style( 'style.css' );
} );

function wl_wa_link( $text = '' ) {
	return 'https://wa.me/' . WL_WHATSAPP . ( $text !== '' ? '?text=' . rawurlencode( $text ) : '' );
}

function wl_money( $amount ) {
	return '$' . number_format( (float) $amount );
}

/**
 * Specs as label => value pairs, from the "Label: value" lines staff type on the product screen.
 */
function wl_specs( $product_id ) {
	$out = [];
	foreach ( preg_split( '/\R/', (string) get_post_meta( $product_id, '_wl_specs', true ) ) as $line ) {
		$parts = array_map( 'trim', explode( ':', $line, 2 ) );
		if ( count( $parts ) === 2 && $parts[0] !== '' ) {
			$out[ $parts[0] ] = $parts[1];
		}
	}
	return $out;
}

/** "ready", "order" or "" from the product's availability tag and stock. */
function wl_availability( WC_Product $product ) {
	if ( $product->is_on_backorder() || has_term( 'on-order', 'product_tag', $product->get_id() ) ) {
		return 'order';
	}
	if ( $product->is_in_stock() && has_term( 'ready-in-nairobi', 'product_tag', $product->get_id() ) ) {
		return 'ready';
	}
	return '';
}

function wl_badges_html( WC_Product $product ) {
	$h = '';
	$avail = wl_availability( $product );
	if ( ! $product->is_in_stock() ) {
		$h .= '<span class="wl-badge wl-badge--out">Sold</span>';
	} elseif ( $avail === 'ready' ) {
		$h .= '<span class="wl-badge wl-badge--ready">Ready in Nairobi</span>';
	} elseif ( $avail === 'order' ) {
		$h .= '<span class="wl-badge wl-badge--order">On order</span>';
	}
	$cond = get_post_meta( $product->get_id(), '_wl_condition', true );
	if ( $cond ) {
		$h .= '<span class="wl-badge">' . esc_html( $cond ) . '</span>';
	}
	return $h ? '<div class="wl-badges">' . $h . '</div>' : '';
}

// Pieces on order are reserved rather than bought outright.
add_filter( 'woocommerce_product_single_add_to_cart_text', fn( $t, $p ) => $p && wl_availability( $p ) === 'order' ? 'Reserve this piece' : 'Add to bag', 10, 2 );
add_filter( 'woocommerce_product_add_to_cart_text', fn( $t, $p ) => $p && $p->is_purchasable() && $p->is_in_stock() ? ( wl_availability( $p ) === 'order' ? 'Reserve' : 'Add to bag' ) : $t, 10, 2 );
add_filter( 'woocommerce_get_availability_text', function ( $text, $product ) {
	if ( $product->is_on_backorder() ) {
		return 'On order – we confirm the delivery date when we call';
	}
	if ( $product->is_in_stock() ) {
		return wl_availability( $product ) === 'ready' ? 'Ready in Nairobi – one piece' : 'One piece available';
	}
	return 'Sold';
}, 10, 2 );

/* -------------------------------------------------------------------------
 * Product page
 * ---------------------------------------------------------------------- */

// Key specs above the add-to-cart button (availability and condition already sit above the price).
add_action( 'woocommerce_before_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$specs = wl_specs( $product->get_id() );
	$keys  = array_intersect_key( $specs, array_flip( [ 'Reference', 'Case', 'Movement', 'Box & papers' ] ) );
	if ( ! $keys ) {
		return;
	}
	echo '<ul class="wl-keyspecs">';
	foreach ( $keys as $k => $v ) {
		echo '<li><span>' . esc_html( $k ) . '</span><strong>' . esc_html( $v ) . '</strong></li>';
	}
	echo '</ul>';
} );

// Enquire on WhatsApp and buying promises under the add-to-cart button.
add_action( 'woocommerce_after_add_to_cart_form', function () {
	global $product;
	if ( ! $product instanceof WC_Product ) {
		return;
	}
	$msg = 'Hi Watchlist, I\'m interested in the ' . $product->get_name() . ' (' . wl_money( $product->get_price() ) . '). ' . $product->get_permalink();
	echo '<a class="wl-wa-order" href="' . esc_url( wl_wa_link( $msg ) ) . '" target="_blank" rel="noopener"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M12 2a10 10 0 0 0-8.6 15.1L2 22l5-1.3A10 10 0 1 0 12 2Zm5.3 14.2c-.2.6-1.3 1.2-1.8 1.2-.5.1-1 .2-3.3-.7-2.8-1.1-4.5-3.9-4.7-4.1-.1-.2-1.1-1.5-1.1-2.9s.7-2 1-2.3c.2-.3.5-.3.7-.3h.5c.2 0 .4 0 .6.5l.8 2c.1.2.1.3 0 .5l-.4.6-.4.4c-.1.2-.3.3-.1.6.2.3.8 1.3 1.7 2.1 1.2 1 2.1 1.3 2.4 1.5.3.1.5.1.7-.1l.9-1.1c.2-.3.4-.2.7-.1l1.9.9c.3.1.5.2.5.3.1.2.1.7-.1 1.2Z"/></svg>Enquire on WhatsApp</a>';

	echo '<div class="wl-promise"><div><span aria-hidden="true">◆</span><p><strong>Inspect before you pay</strong>Cash on delivery: see the watch and everything that comes with it in person, then pay.</p></div><div><span aria-hidden="true">◷</span><p><strong>Hand delivered in Nairobi</strong>We bring it to you and walk you through it. Countrywide delivery by arrangement.</p></div><div><span aria-hidden="true">✦</span><p><strong>More photos and videos</strong>Ask on WhatsApp for a live video of this exact piece.</p></div></div>';
} );

// Specs, care and delivery tabs.
add_filter( 'woocommerce_product_tabs', function ( $tabs ) {
	global $product;
	if ( ! $product ) {
		return $tabs;
	}
	$specs = wl_specs( $product->get_id() );
	if ( $specs ) {
		$tabs['wl_specs'] = [
			'title'    => 'Specifications',
			'priority' => 5,
			'callback' => function () use ( $specs ) {
				echo '<table class="wl-spec-table"><tbody>';
				foreach ( $specs as $k => $v ) {
					echo '<tr><th>' . esc_html( $k ) . '</th><td>' . esc_html( $v ) . '</td></tr>';
				}
				echo '</tbody></table>';
			},
		];
	}
	$tabs['wl_care'] = [
		'title'    => 'Care',
		'priority' => 25,
		'callback' => function () {
			echo '<ul><li><strong>Automatic watches</strong> wind themselves as you wear them. If one stops after a few days in the drawer, wind it 20–30 turns at the crown, or keep it on a watch winder.</li><li><strong>Water resistance</strong> fades with age and knocks. Keep the crown screwed down, rinse in fresh water after the sea or pool, and have the seals checked every couple of years.</li><li><strong>Magnets</strong> from speakers, laptops and phone cases can make a watch run fast. Keep it a hand\'s width away.</li><li><strong>Leather straps</strong> don\'t like water or sweat. Rubber and steel do, so swap for the gym or the beach.</li><li><strong>Servicing:</strong> most mechanical watches want a full service every 5–10 years. Ask us and we\'ll point you to a service centre.</li></ul>';
		},
	];
	$tabs['wl_delivery'] = [
		'title'    => 'Delivery & payment',
		'priority' => 30,
		'callback' => function () {
			echo '<ul><li><strong>Cash on delivery:</strong> we bring the watch to you, you inspect it and everything that comes with it, and you pay on hand-over. We confirm the amount and how you\'ll pay when we call.</li><li><strong>Nairobi:</strong> hand delivery at a time that suits you.</li><li><strong>Outside Nairobi:</strong> we call to arrange delivery.</li><li><strong>Pieces on order:</strong> reserve the watch here and we\'ll confirm the arrival date before anything else happens.</li><li><strong>Prices</strong> are in US dollars, as we quote them.</li></ul>';
		},
	];
	// The description already shows next to the photos.
	unset( $tabs['description'], $tabs['additional_information'] );
	return $tabs;
}, 20 );

/* -------------------------------------------------------------------------
 * Product cards
 * ---------------------------------------------------------------------- */

function wl_card_product( $instance ) {
	$id = $instance->context['postId'] ?? get_the_ID();
	return $id && ! is_admin() ? wc_get_product( $id ) : null;
}

const WL_HEART = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg>';

// Hover image (first gallery photo), wishlist heart and quick view on product images.
add_filter( 'render_block_woocommerce/product-image', function ( $content, $block, $instance ) {
	$product = wl_card_product( $instance );
	if ( ! $product || empty( $block['attrs']['isDescendentOfQueryLoop'] ) ) {
		return $content;
	}
	$gallery = $product->get_gallery_image_ids();
	if ( $gallery ) {
		$alt = wp_get_attachment_image( $gallery[0], 'woocommerce_thumbnail', false, [ 'class' => 'wl-alt-img', 'alt' => '', 'loading' => 'lazy' ] );
		$content = preg_replace( '#(<img[^>]*>)#', '$1' . $alt, $content, 1 );
	}
	$extra = sprintf(
		'<button type="button" class="wl-heart" data-wl-wish="%1$d" aria-label="Save %2$s to your watchlist" aria-pressed="false">%3$s</button><button type="button" class="wl-qv-btn" data-wl-qv="%1$d" aria-label="Quick view of %2$s">Quick view</button>',
		$product->get_id(),
		esc_attr( $product->get_name() ),
		WL_HEART
	);
	$pos = strrpos( $content, '</div>' );
	return $pos === false ? $content : substr_replace( $content, $extra . '</div>', $pos, 6 );
}, 10, 3 );

// Brand above the title.
add_filter( 'render_block_core/post-title', function ( $content, $block, $instance ) {
	if ( empty( $block['attrs']['__woocommerceNamespace'] ) ) {
		return $content;
	}
	$product = wl_card_product( $instance );
	$brands  = $product && taxonomy_exists( 'product_brand' ) ? wp_get_post_terms( $product->get_id(), 'product_brand', [ 'fields' => 'names' ] ) : [];
	return ( $brands && ! is_wp_error( $brands ) ? '<p class="wl-card-brand">' . esc_html( $brands[0] ) . '</p>' : '' ) . $content;
}, 10, 3 );

// Availability and condition above the price.
add_filter( 'render_block_woocommerce/product-price', function ( $content, $block, $instance ) {
	$product = wl_card_product( $instance );
	return $product ? wl_badges_html( $product ) . $content : $content;
}, 10, 3 );

/* -------------------------------------------------------------------------
 * Home page and shop sections
 * ---------------------------------------------------------------------- */

function wl_categories() {
	$terms = get_terms( [ 'taxonomy' => 'product_cat', 'hide_empty' => true, 'exclude' => [ (int) get_option( 'default_product_cat' ) ], 'orderby' => 'meta_value_num', 'meta_key' => 'order' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

// "Shop by style": one tile per category, shown with a photo of its first watch.
add_shortcode( 'wl_styles', function () {
	$h = '<div class="wl-styles">';
	foreach ( wl_categories() as $t ) {
		$first = wc_get_products( [ 'category' => [ $t->slug ], 'limit' => 1, 'orderby' => 'menu_order', 'order' => 'ASC', 'status' => 'publish' ] );
		$img   = $first ? $first[0]->get_image( 'woocommerce_thumbnail', [ 'loading' => 'lazy', 'alt' => '' ] ) : '';
		$h .= sprintf(
			'<a class="wl-style" href="%s"><span class="wl-style__img">%s</span><span class="wl-style__txt"><strong>%s</strong><em>%s</em></span></a>',
			esc_url( get_term_link( $t ) ),
			$img,
			esc_html( $t->name ),
			esc_html( sprintf( _n( '%d piece', '%d pieces', $t->count ), $t->count ) )
		);
	}
	return $h . '</div>';
} );

function wl_brands() {
	if ( ! taxonomy_exists( 'product_brand' ) ) {
		return [];
	}
	$terms = get_terms( [ 'taxonomy' => 'product_brand', 'hide_empty' => true, 'orderby' => 'name' ] );
	return is_wp_error( $terms ) ? [] : $terms;
}

add_shortcode( 'wl_brands', function () {
	$brands = wl_brands();
	if ( ! $brands ) {
		return '';
	}
	$h = '<div class="wl-brands">';
	foreach ( $brands as $t ) {
		$h .= '<a href="' . esc_url( get_term_link( $t ) ) . '">' . esc_html( $t->name ) . '</a>';
	}
	return $h . '</div>';
} );

function wl_chip( $label, $url, $on, $count = null, $small = false ) {
	return sprintf( '<a class="wl-chip%s%s" href="%s">%s%s</a>', $small ? ' wl-chip--sm' : '', $on ? ' is-on' : '', esc_url( $url ), esc_html( $label ), $count === null ? '' : ' <em>' . (int) $count . '</em>' );
}

// Style, availability and brand chips above shop, category, tag, brand and search results.
add_shortcode( 'wl_filters', function () {
	$current = get_queried_object();
	$cur_id  = $current instanceof WP_Term ? $current->term_id : 0;
	$h = '<nav class="wl-filters" aria-label="Filter watches"><div class="wl-filters__row">';
	$h .= wl_chip( 'All watches', wc_get_page_permalink( 'shop' ), is_shop() );
	foreach ( wl_categories() as $t ) {
		$h .= wl_chip( $t->name, get_term_link( $t ), $t->term_id === $cur_id, $t->count );
	}
	$h .= '</div><div class="wl-filters__row"><span>Availability</span>';
	foreach ( [ 'ready-in-nairobi', 'on-order' ] as $slug ) {
		$t = get_term_by( 'slug', $slug, 'product_tag' );
		if ( $t && $t->count ) {
			$h .= wl_chip( $t->name, get_term_link( $t ), $t->term_id === $cur_id, $t->count, true );
		}
	}
	$brands = wl_brands();
	if ( $brands ) {
		$h .= '</div><div class="wl-filters__row"><span>Brand</span>';
		foreach ( $brands as $t ) {
			$h .= wl_chip( $t->name, get_term_link( $t ), $t->term_id === $cur_id, null, true );
		}
	}
	return $h . '</div></nav>';
} );

add_shortcode( 'wl_wishlist', function () {
	return '<div class="wl-wishlist" data-wl-wishlist><p class="wl-small">Loading your saved watches…</p></div>';
} );

// Quick view pop-up, filled in by wl.js.
add_action( 'wp_footer', function () {
	echo '<dialog id="wl-qv" class="wl-dialog wl-qv" aria-label="Quick view"><form method="dialog"><button class="wl-dialog__close" aria-label="Close">×</button></form><div data-wl-qv-body></div></dialog>';
} );

/* -------------------------------------------------------------------------
 * Cart, checkout, order confirmation
 * ---------------------------------------------------------------------- */

function wl_cart_note_html() {
	return '<div class="wl-cart-note"><strong>Cash on delivery.</strong> Inspect the watch in person, then pay on hand-over.</div>';
}
function wl_wa_cart_html() {
	return '<button type="button" class="wl-wa-cart" data-wl-wa-cart>Send this bag to us on WhatsApp</button>';
}
add_filter( 'render_block_woocommerce/cart', fn( $c ) => wl_cart_note_html() . $c );
add_filter( 'render_block_woocommerce/proceed-to-checkout-block', fn( $c ) => $c . wl_wa_cart_html() );
add_filter( 'render_block_woocommerce/mini-cart-contents', function ( $c ) {
	return preg_replace( '#(<div[^>]*wp-block-woocommerce-filled-mini-cart-contents-block[^>]*>)#', '$1' . wl_cart_note_html(), $c, 1 );
} );
add_filter( 'render_block_woocommerce/mini-cart-footer-block', fn( $c ) => $c . '<div class="wl-wa-cart-wrap">' . wl_wa_cart_html() . '</div>' );

// A landmark helps the delivery reach the customer.
add_action( 'woocommerce_init', function () {
	if ( ! function_exists( 'woocommerce_register_additional_checkout_field' ) ) {
		return;
	}
	woocommerce_register_additional_checkout_field( [
		'id'       => 'wl/landmark',
		'label'    => 'Building, office or nearest landmark',
		'location' => 'address',
		'type'     => 'text',
		'required' => false,
	] );
} );

// Tracking code and WhatsApp summary on the order confirmation page.
function wl_tracking_code( WC_Order $order ) {
	return 'WL-' . $order->get_order_number() . '-' . strtoupper( substr( $order->get_order_key(), -4 ) );
}
function wl_whatsapp_order_link( WC_Order $order ) {
	$lines = [ 'Hi Watchlist, I just placed order ' . wl_tracking_code( $order ) . ':' ];
	foreach ( $order->get_items() as $item ) {
		$lines[] = '• ' . $item->get_name() . ' – ' . wl_money( $item->get_total() );
	}
	$lines[] = 'Total: ' . wl_money( $order->get_total() );
	$lines[] = 'Delivery: ' . $order->get_shipping_method();
	$address = trim( implode( ', ', array_filter( [ $order->get_shipping_address_1(), $order->get_shipping_city() ] ) ) );
	if ( $address ) {
		$lines[] = 'Deliver to: ' . $address;
	}
	$lines[] = 'Name: ' . $order->get_formatted_billing_full_name() . ', ' . $order->get_billing_phone();
	return wl_wa_link( implode( "\n", $lines ) );
}
add_filter( 'render_block_woocommerce/order-confirmation-status', function ( $content ) {
	$order_id = absint( get_query_var( 'order-received' ) );
	$order    = $order_id ? wc_get_order( $order_id ) : null;
	if ( ! $order || ! hash_equals( $order->get_order_key(), wc_clean( wp_unslash( $_GET['key'] ?? '' ) ) ) ) {
		return $content;
	}
	return $content . '<div class="wl-thanks"><p class="wl-thanks__code">Order code <strong>' . esc_html( wl_tracking_code( $order ) ) . '</strong></p><p>We\'ll call you shortly to confirm and arrange delivery. For the quickest reply, send your order summary to us on WhatsApp.</p><a class="wp-element-button wl-wa-btn" href="' . esc_attr( wl_whatsapp_order_link( $order ) ) . '" target="_blank" rel="noopener">Send order summary to WhatsApp</a></div>';
} );
add_action( 'woocommerce_admin_order_data_after_order_details', function ( $order ) {
	echo '<p class="form-field form-field-wide"><strong>Order code:</strong> ' . esc_html( wl_tracking_code( $order ) ) . '</p>';
} );

// Newsletter: new arrivals first. Staff see the list under WooCommerce → VIP list.
add_action( 'admin_post_nopriv_wl_subscribe', 'wl_subscribe' );
add_action( 'admin_post_wl_subscribe', 'wl_subscribe' );
function wl_subscribe() {
	check_admin_referer( 'wl_subscribe' );
	$email = sanitize_email( wp_unslash( $_POST['email'] ?? '' ) );
	$back  = wp_get_referer() ?: home_url( '/' );
	if ( ! is_email( $email ) ) {
		wp_safe_redirect( add_query_arg( 'wl_sub', 'invalid', $back ) . '#newsletter' );
		exit;
	}
	$list = get_option( 'wl_subscribers', [] );
	$list[ strtolower( $email ) ] = current_time( 'mysql' );
	update_option( 'wl_subscribers', $list, false );
	wp_safe_redirect( add_query_arg( 'wl_sub', 'ok', $back ) . '#newsletter' );
	exit;
}

add_shortcode( 'wl_newsletter', function () {
	$state = sanitize_key( $_GET['wl_sub'] ?? '' );
	if ( $state === 'ok' ) {
		return '<p class="wl-news-ok"><strong>You\'re on the list.</strong> New pieces reach you before they go on Instagram.</p>';
	}
	$err = $state === 'invalid' ? '<p class="wl-news-err">Please enter a valid email address.</p>' : '';
	return '<form class="wl-news-form" method="post" action="' . esc_url( admin_url( 'admin-post.php' ) ) . '">'
		. '<input type="hidden" name="action" value="wl_subscribe">'
		. wp_nonce_field( 'wl_subscribe', '_wpnonce', true, false )
		. '<input type="email" name="email" required placeholder="Your email address" aria-label="Email address">'
		. '<button class="wp-element-button" type="submit">Join the list</button>'
		. '</form>' . $err;
} );

add_action( 'admin_menu', function () {
	add_submenu_page( 'woocommerce', 'VIP list', 'VIP list', 'manage_woocommerce', 'wl-subscribers', function () {
		$list = get_option( 'wl_subscribers', [] );
		echo '<div class="wrap"><h1>VIP list (' . count( $list ) . ')</h1><table class="widefat striped"><thead><tr><th>Email</th><th>Signed up</th></tr></thead><tbody>';
		foreach ( array_reverse( $list, true ) as $email => $when ) {
			echo '<tr><td>' . esc_html( $email ) . '</td><td>' . esc_html( $when ) . '</td></tr>';
		}
		echo '</tbody></table></div>';
	} );
} );

// Staff edit condition, box & papers and specs on the product screen.
add_action( 'woocommerce_product_options_general_product_data', function () {
	woocommerce_wp_text_input( [ 'id' => '_wl_condition', 'label' => 'Condition', 'description' => 'Shown on the product card, e.g. "New", "Like new", "Pre-owned".', 'desc_tip' => true ] );
	woocommerce_wp_text_input( [ 'id' => '_wl_set', 'label' => 'Box & papers', 'description' => 'What comes with it, e.g. "Full set", "Watch and box".', 'desc_tip' => true ] );
	woocommerce_wp_textarea_input( [ 'id' => '_wl_specs', 'label' => 'Specifications', 'rows' => 8, 'description' => 'One per line, as "Label: value", e.g. "Case: Oystersteel, 40 mm". Reference, Case, Movement and Box & papers also show next to the price.' ] );
	echo '<p class="form-field"><em>Availability: tag the watch "Ready in Nairobi" or "On order" (Product tags box). For pieces on order, set stock to 0 and allow backorders.</em></p>';
} );
add_action( 'woocommerce_admin_process_product_object', function ( $product ) {
	foreach ( [ '_wl_condition' => 'sanitize_text_field', '_wl_set' => 'sanitize_text_field', '_wl_specs' => 'sanitize_textarea_field' ] as $key => $clean ) {
		if ( isset( $_POST[ $key ] ) ) {
			$product->update_meta_data( $key, $clean( wp_unslash( $_POST[ $key ] ) ) );
		}
	}
} );

/* -------------------------------------------------------------------------
 * Housekeeping
 * ---------------------------------------------------------------------- */

// Kenyan addresses: no postcode, and we need a phone number to arrange delivery.
add_filter( 'woocommerce_get_country_locale', function ( $locale ) {
	$locale['KE']['postcode'] = [ 'required' => false, 'hidden' => true ];
	$locale['KE']['city']     = [ 'label' => 'Area / Estate / Town (e.g. Westlands, Karen, Mombasa)' ];
	$locale['KE']['phone']    = [ 'required' => true ];
	return $locale;
} );

// Local preview only: the SQLite layer can't run WooCommerce's stock-reservation query.
// Real hosting uses MySQL, where this never triggers.
if ( isset( $GLOBALS['wpdb'] ) && stripos( get_class( $GLOBALS['wpdb'] ), 'sqlite' ) !== false ) {
	add_filter( 'woocommerce_hold_stock_for_checkout', '__return_false' );
}

// Browser tab icon.
add_action( 'wp_head', function () {
	if ( has_site_icon() ) {
		return;
	}
	$src = esc_url( get_stylesheet_directory_uri() . '/assets/icon.png' );
	echo "<link rel=\"icon\" href=\"$src\">\n<link rel=\"apple-touch-icon\" href=\"$src\">\n<meta name=\"theme-color\" content=\"#0D0D0D\">\n";
} );

// Templates use root-relative links ("/shop/"); point them at the real home URL so the site
// also works from a sub-folder (e.g. the WordPress Playground demo).
add_filter( 'render_block', function ( $content ) {
	$home = trailingslashit( home_url() );
	if ( $home === '/' || ! str_contains( $content, '="/' ) ) {
		return $content;
	}
	return preg_replace( '#\b(href|src)="/(?!/)#', '$1="' . $home, $content );
} );
