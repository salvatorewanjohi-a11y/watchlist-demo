( function () {
	const cfg = window.WL || {};
	const fmt = ( n ) => '$' + Math.round( n ).toLocaleString( 'en-US' );
	const $$ = ( sel, root = document ) => Array.from( root.querySelectorAll( sel ) );
	const esc = ( s ) => String( s ).replace( /[&<>"']/g, ( c ) => ( { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' } )[ c ] );
	// Store API names come HTML-encoded (e.g. &#8211;); turn them back into plain text.
	const plain = ( s ) => new DOMParser().parseFromString( String( s ), 'text/html' ).documentElement.textContent;
	const money = ( minor, prices ) => Number( minor ) / Math.pow( 10, ( prices && prices.currency_minor_unit ) || 0 );
	const heart = '<svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path d="M12 20.3 4.6 13a4.8 4.8 0 0 1 6.8-6.8l.6.6.6-.6a4.8 4.8 0 0 1 6.8 6.8Z"/></svg>';

	/* Toasts ------------------------------------------------------------ */
	function toast( msg ) {
		let box = document.querySelector( '.wl-toasts' );
		if ( ! box ) {
			box = document.createElement( 'div' );
			box.className = 'wl-toasts';
			box.setAttribute( 'role', 'status' );
			box.setAttribute( 'aria-live', 'polite' );
			document.body.appendChild( box );
		}
		const t = document.createElement( 'div' );
		t.className = 'wl-toast';
		t.innerHTML = msg;
		box.appendChild( t );
		setTimeout( () => t.classList.add( 'is-out' ), 3200 );
		setTimeout( () => t.remove(), 3700 );
	}
	document.body.addEventListener( 'wc-blocks_added_to_cart', () => toast( '✓ Added to your bag' ) );
	if ( window.jQuery ) window.jQuery( document.body ).on( 'added_to_cart', () => toast( '✓ Added to your bag' ) );

	/* Store API ---------------------------------------------------------- */
	let nonce = '';
	async function getCart() {
		const res = await fetch( cfg.store + 'cart', { credentials: 'same-origin' } );
		nonce = res.headers.get( 'Nonce' ) || nonce;
		return res.json();
	}
	// The header mini cart keeps its own copy of the cart (Interactivity API, or wp.data on
	// older WooCommerce); tell whichever is on the page to reload it.
	async function refreshMiniCart( cart ) {
		try {
			const { store } = await import( '@wordpress/interactivity' );
			const wc = store( 'woocommerce' );
			if ( wc && wc.actions && wc.actions.refreshCartItems ) await wc.actions.refreshCartItems();
		} catch ( e ) {}
		const data = window.wp && window.wp.data;
		if ( cart && data && data.dispatch( 'wc/store/cart' ) && data.dispatch( 'wc/store/cart' ).receiveCart ) {
			data.dispatch( 'wc/store/cart' ).receiveCart( cart );
		}
	}

	async function addToCart( id, btn ) {
		if ( btn ) btn.disabled = true;
		try {
			if ( ! nonce ) await getCart();
			const res = await fetch( cfg.store + 'cart/add-item', {
				method: 'POST',
				credentials: 'same-origin',
				headers: { 'Content-Type': 'application/json', Nonce: nonce },
				body: JSON.stringify( { id: Number( id ), quantity: 1 } ),
			} );
			const cart = await res.json();
			if ( ! res.ok ) throw new Error( plain( cart.message || 'Could not add' ) );
			await refreshMiniCart( cart );
			// The mini cart opens its drawer on this event; our toast listens too.
			document.body.dispatchEvent( new CustomEvent( 'wc-blocks_added_to_cart', { bubbles: true } ) );
			// The drawer can briefly re-show an older copy while it opens; refresh once more after.
			setTimeout( () => refreshMiniCart(), 900 );
		} catch ( e ) {
			toast( esc( e.message || 'Could not add to your bag. Please try again.' ) );
		} finally {
			if ( btn ) btn.disabled = false;
		}
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-wl-add]' );
		if ( ! b ) return;
		e.preventDefault();
		addToCart( b.dataset.wlAdd, b );
	} );

	/* WhatsApp checkout -------------------------------------------------- */
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-wl-wa-cart]' );
		if ( ! b ) return;
		e.preventDefault();
		// Open the tab now (inside the click) so pop-up blockers allow it, then fill in the link.
		const win = window.open( '', '_blank' );
		try {
			const cart = await getCart();
			if ( ! cart.items || ! cart.items.length ) {
				if ( win ) win.close();
				toast( 'Your bag is empty.' );
				return;
			}
			const lines = [ cart.items.length > 1 ? 'Hi Watchlist, I\'d like these pieces:' : 'Hi Watchlist, I\'d like this piece:' ];
			cart.items.forEach( ( it ) => {
				lines.push( '• ' + plain( it.name ) + ' – ' + fmt( money( it.totals.line_total, it.totals ) ) );
			} );
			if ( cart.items.length > 1 ) lines.push( 'Total: ' + fmt( money( cart.totals.total_items, cart.totals ) ) );
			lines.push( 'Delivery to: ' );
			const url = 'https://wa.me/' + cfg.wa + '?text=' + encodeURIComponent( lines.join( '\n' ) );
			if ( win ) win.location = url;
			else window.location = url;
		} catch ( err ) {
			if ( win ) win.close();
			toast( 'Could not read your bag. Please try again.' );
		}
	} );

	/* Saved watches ------------------------------------------------------ */
	const KEY = 'wl-wishlist';
	const readWish = () => {
		try {
			return JSON.parse( localStorage.getItem( KEY ) || '[]' ).map( Number ).filter( Boolean );
		} catch ( e ) {
			return [];
		}
	};
	const writeWish = ( ids ) => {
		try {
			localStorage.setItem( KEY, JSON.stringify( ids ) );
		} catch ( e ) {}
	};
	function paintWish() {
		const ids = readWish();
		// Only touch the DOM when something changed: the MutationObserver below calls this.
		$$( '[data-wl-wish]' ).forEach( ( b ) => {
			const on = ids.includes( Number( b.dataset.wlWish ) );
			if ( b.classList.contains( 'is-on' ) === on ) return;
			b.classList.toggle( 'is-on', on );
			b.setAttribute( 'aria-pressed', on ? 'true' : 'false' );
		} );
		$$( '[data-wl-wish-count]' ).forEach( ( el ) => {
			if ( el.textContent !== String( ids.length ) ) el.textContent = ids.length;
			el.hidden = ids.length === 0;
		} );
	}
	document.addEventListener( 'click', ( e ) => {
		const b = e.target.closest( '[data-wl-wish]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const id = Number( b.dataset.wlWish );
		let ids = readWish();
		const on = ids.includes( id );
		ids = on ? ids.filter( ( x ) => x !== id ) : [ ...ids, id ];
		writeWish( ids );
		paintWish();
		toast( on ? 'Removed from your saved watches' : '♥ Saved to <a href="' + esc( cfg.home || '/' ) + 'wishlist/">your watchlist</a>' );
		if ( b.closest( '[data-wl-wishlist]' ) ) renderWishlist();
	} );

	async function renderWishlist() {
		const box = document.querySelector( '[data-wl-wishlist]' );
		if ( ! box ) return;
		const ids = readWish();
		if ( ! ids.length ) {
			box.innerHTML = '<div class="wl-empty"><p>Nothing saved yet. Tap the ♥ on any watch to keep it here.</p><a class="wp-element-button" href="' + esc( cfg.shop || '/shop/' ) + '">Browse the collection</a></div>';
			return;
		}
		try {
			const res = await fetch( cfg.store + 'products?include=' + ids.join( ',' ) + '&per_page=50' );
			const items = await res.json();
			box.innerHTML = '<div class="wl-wish-grid">' + items.map( ( p ) => {
				const img = p.images && p.images[ 0 ] ? '<img src="' + esc( p.images[ 0 ].thumbnail || p.images[ 0 ].src ) + '" alt="" loading="lazy">' : '';
				return '<article class="wl-wish-card"><a href="' + esc( p.permalink ) + '">' + img + '</a>' +
					'<button type="button" class="wl-heart is-on" data-wl-wish="' + p.id + '" aria-label="Remove from saved watches" aria-pressed="true">' + heart + '</button>' +
					'<h3><a href="' + esc( p.permalink ) + '">' + p.name + '</a></h3><div class="wl-wish-price">' + p.price_html + '</div>' +
					( p.is_purchasable && ( p.is_in_stock || p.is_on_backorder ) ? '<button type="button" class="wp-element-button" data-wl-add="' + p.id + '">' + ( p.is_on_backorder ? 'Reserve' : 'Add to bag' ) + '</button>' : '<a class="wp-element-button" href="' + esc( p.permalink ) + '">View</a>' ) + '</article>';
			} ).join( '' ) + '</div>';
		} catch ( e ) {
			box.innerHTML = '<p>Could not load your saved watches. Please refresh the page.</p>';
		}
	}

	/* Quick view --------------------------------------------------------- */
	document.addEventListener( 'click', async ( e ) => {
		const b = e.target.closest( '[data-wl-qv]' );
		if ( ! b ) return;
		e.preventDefault();
		e.stopPropagation();
		const dlg = document.getElementById( 'wl-qv' );
		const body = dlg && dlg.querySelector( '[data-wl-qv-body]' );
		if ( ! body || ! dlg.showModal ) return;
		body.innerHTML = '<p class="wl-small">Loading…</p>';
		dlg.showModal();
		try {
			const p = await ( await fetch( cfg.store + 'products/' + b.dataset.wlQv ) ).json();
			const imgs = ( p.images || [] ).map( ( im, i ) => '<img src="' + esc( im.src ) + '" alt="' + esc( im.alt || plain( p.name ) ) + '"' + ( i ? ' hidden' : '' ) + '>' ).join( '' );
			const thumbs = ( p.images || [] ).length > 1 ? '<div class="wl-qv__thumbs">' + p.images.map( ( im, i ) => '<button type="button" data-wl-qv-img="' + i + '"><img src="' + esc( im.thumbnail || im.src ) + '" alt=""></button>' ).join( '' ) + '</div>' : '';
			const brand = p.brands && p.brands[ 0 ] ? p.brands[ 0 ].name : ( p.categories && p.categories[ 0 ] ? p.categories[ 0 ].name : '' );
			const buy = p.is_purchasable && ( p.is_in_stock || p.is_on_backorder )
				? '<button type="button" class="wp-element-button" data-wl-add="' + p.id + '">' + ( p.is_on_backorder ? 'Reserve this piece' : 'Add to bag' ) + '</button>'
				: '<span class="wl-badge wl-badge--out">Sold</span>';
			body.innerHTML = '<div class="wl-qv__grid"><div class="wl-qv__media"><div class="wl-qv__main">' + imgs + '</div>' + thumbs + '</div>' +
				'<div class="wl-qv__info">' + ( brand ? '<p class="wl-eyebrow">' + esc( plain( brand ) ) + '</p>' : '' ) + '<h2>' + p.name + '</h2><div class="wl-qv__price">' + p.price_html + '</div>' +
				( p.is_on_backorder ? '<div class="wl-badges"><span class="wl-badge wl-badge--order">On order</span></div>' : '' ) +
				'<div class="wl-qv__desc">' + ( p.short_description || '' ) + '</div>' +
				'<div class="wl-qv__actions">' + buy + '<a class="wl-link" href="' + esc( p.permalink ) + '">Full specifications →</a></div></div></div>';
		} catch ( err ) {
			body.innerHTML = '<p>Could not load this watch. Please try again.</p>';
		}
	} );
	document.addEventListener( 'click', ( e ) => {
		const t = e.target.closest( '[data-wl-qv-img]' );
		if ( ! t ) return;
		const main = t.closest( '.wl-qv__media' ).querySelectorAll( '.wl-qv__main img' );
		main.forEach( ( im, i ) => ( im.hidden = i !== Number( t.dataset.wlQvImg ) ) );
	} );
	document.addEventListener( 'click', ( e ) => {
		if ( e.target.matches( 'dialog.wl-dialog' ) ) e.target.close();
	} );

	/* Instant search ----------------------------------------------------- */
	function initSearch() {
		$$( '.wl-search input[type="search"]' ).forEach( ( input ) => {
			const form = input.closest( 'form' );
			const list = document.createElement( 'div' );
			list.className = 'wl-suggest';
			list.hidden = true;
			form.style.position = 'relative';
			form.appendChild( list );
			let timer;
			let seq = 0;
			input.setAttribute( 'autocomplete', 'off' );
			input.addEventListener( 'input', () => {
				clearTimeout( timer );
				const q = input.value.trim();
				if ( q.length < 2 ) {
					list.hidden = true;
					return;
				}
				timer = setTimeout( async () => {
					const mine = ++seq;
					try {
						const res = await fetch( cfg.store + 'products?search=' + encodeURIComponent( q ) + '&per_page=6' );
						const items = await res.json();
						if ( mine !== seq ) return;
						list.innerHTML = items.length
							? items.map( ( p ) => '<a href="' + esc( p.permalink ) + '">' + ( p.images[ 0 ] ? '<img src="' + esc( p.images[ 0 ].thumbnail ) + '" alt="">' : '' ) + '<span>' + p.name + '<small>' + p.price_html + '</small></span></a>' ).join( '' ) + '<button type="submit">See all results for “' + esc( q ) + '”</button>'
							: '<p>Nothing on the list matches “' + esc( q ) + '”. <a href="https://wa.me/' + esc( cfg.wa ) + '?text=' + encodeURIComponent( 'Hi Watchlist, can you find me a ' + q + '?' ) + '">Ask us to source it</a></p>';
						list.hidden = false;
					} catch ( e ) {}
				}, 180 );
			} );
			document.addEventListener( 'click', ( e ) => {
				if ( ! form.contains( e.target ) ) list.hidden = true;
			} );
			input.addEventListener( 'keydown', ( e ) => {
				if ( e.key === 'Escape' ) list.hidden = true;
			} );
		} );
	}

	function init() {
		paintWish();
		renderWishlist();
		initSearch();
		// Cards re-render client-side in some blocks; keep hearts in sync.
		new MutationObserver( () => paintWish() ).observe( document.body, { childList: true, subtree: true } );
	}
	if ( document.readyState === 'loading' ) document.addEventListener( 'DOMContentLoaded', init );
	else init();
} )();
